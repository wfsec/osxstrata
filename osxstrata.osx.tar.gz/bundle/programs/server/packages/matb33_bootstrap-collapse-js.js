(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['matb33:bootstrap-collapse-js'] = {};

})();

//# sourceMappingURL=matb33_bootstrap-collapse-js.js.map

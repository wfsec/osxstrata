(function(){Meteor.methods({
	importDB: function (line) {
		var errors = []
		json = JSON.parse(line)
		console.log(json.osxcollector_section)
		switch (json.osxcollector_section)
		{
			case 'mail':
				try{
				
				var id = Mail.insert(json)
				return Mail.update({_id:id},{$set:{checked:false,flagged:false,vt_results:0,ibm_results:0,shadow_results:0}})
				}
				catch(err){
					return Import_Errors.insert({osxcollector_incident_id:json.osxcollector_incident_id, error: String(err), json: line,checked: false})
					
				}
				break
			case 'kext':
				try{
				var id = Kext.insert(json)
				return Kext.update({_id:id},{$set:{checked:false,flagged:false,vt_results:0,ibm_results:0,shadow_results:0}})	
				}			
				catch(err){
					return Import_Errors.insert({osxcollector_incident_id:json.osxcollector_incident_id, error: String(err), json: line,checked: false})
				}
				break
			case 'startup':
				try{
				var id = Startup.insert(json)
				return Startup.update({_id:id},{$set:{checked:false,flagged:false,vt_results:0,ibm_results:0,shadow_results:0}})			
								}
				catch(err){
					return Import_Errors.insert({osxcollector_incident_id:json.osxcollector_incident_id, error: String(err), json: line,checked: false})
				}
				break
			case 'quarantines':
				try{
				var id = Quarantines.insert(json)
				return Quarantines.update({_id:id},{$set:{checked:false,flagged:false,vt_results:0,ibm_results:0,shadow_results:0}})				
								}
				catch(err){
					return Import_Errors.insert({osxcollector_incident_id:json.osxcollector_incident_id, error: String(err), json: line,checked: false})
				}
				break
			case 'downloads':
				try{
				var id = Downloads.insert(json)
				return Downloads.update({_id:id},{$set:{checked:false,flagged:false,vt_results:0,ibm_results:0,shadow_results:0}})				
								}
				catch(err){
					return Import_Errors.insert({osxcollector_incident_id:json.osxcollector_incident_id, error: String(err), json: line,checked: false})
				}
				break
			case 'chrome':
				try{
				var id = Chrome.insert(json)
				return Chrome.update({_id:id},{$set:{checked:false,flagged:false,vt_results:0,ibm_results:0,shadow_results:0}})				
								}
				catch(err){
					return Import_Errors.insert({osxcollector_incident_id:json.osxcollector_incident_id, error: String(err), json: line,checked: false})
				}
				break
			case 'firefox':
				try{
				var id = Firefox.insert(json)
				return Firefox.update({_id:id},{$set:{checked:false,flagged:false,vt_results:0,ibm_results:0,shadow_results:0}})				
								}
				catch(err){
					return Import_Errors.insert({osxcollector_incident_id:json.osxcollector_incident_id, error: String(err), json: line,checked: false})
				}
				break
			case 'safari':
				try{
				var id = Safari.insert(json)
				return Safari.update({_id:id},{$set:{checked:false,flagged:false,vt_results:0,ibm_results:0,shadow_results:0}})				
								}
				catch(err){
					return Import_Errors.insert({osxcollector_incident_id:json.osxcollector_incident_id, error: String(err), json: line,checked: false})
				}
				break
			case 'accounts':
				try{
				var id = Accounts.insert(json)
				return Accounts.update({_id:id},{$set:{checked:false,flagged:false,vt_results:0,ibm_results:0,shadow_results:0}})				
								}
				catch(err){
					return Import_Errors.insert({osxcollector_incident_id:json.osxcollector_incident_id, error: String(err), json: line,checked: false})
				}
				break
			case 'applications':
				try{
				var id = Applications.insert(json)
				return Applications.update({_id:id},{$set:{checked:false,flagged:false,vt_results:0,ibm_results:0,shadow_results:0}})				
								}
				catch(err){
					return Import_Errors.insert({osxcollector_incident_id:json.osxcollector_incident_id, error: String(err), json: line,checked: false})
				}
				break
			case 'system_info':
				try{
				var id = System_Info.insert(json)
				return System_Info.update({_id:id},{$set:{checked:false,flagged:false,vt_results:0,ibm_results:0,shadow_results:0}})				
								}
				catch(err){
					return Import_Errors.insert({osxcollector_incident_id:json.osxcollector_incident_id, error: String(err), json: line,checked: false})
				}
				break
			default:
				console.log(json)
		}
	}
})

}).call(this);

//# sourceMappingURL=upload.js.map

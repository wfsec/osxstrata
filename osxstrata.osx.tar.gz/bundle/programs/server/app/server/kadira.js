(function(){// Kadira.connect('RjrnSErWwC5C7FgqT', 'ef2c6527-08bd-4089-8aa5-c1b28937aedb');
}).call(this);

//# sourceMappingURL=kadira.js.map

(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['matb33:bootstrap-panels'] = {};

})();

//# sourceMappingURL=matb33_bootstrap-panels.js.map

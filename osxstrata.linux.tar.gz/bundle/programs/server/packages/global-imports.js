/* Imports for global scope */

Router = Package['iron:router'].Router;
RouteController = Package['iron:router'].RouteController;
HTTP = Package.http.HTTP;
HTTPInternals = Package.http.HTTPInternals;
_ = Package.underscore._;
Counts = Package['tmeasday:publish-counts'].Counts;
publishCount = Package['tmeasday:publish-counts'].publishCount;
MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
Log = Package.logging.Log;
Random = Package.random.Random;
EJSON = Package.ejson.EJSON;
Spacebars = Package.spacebars.Spacebars;
check = Package.check.check;
Match = Package.check.Match;
UploadServer = Package['tomi:upload-server'].UploadServer;
Iron = Package['iron:core'].Iron;
AccountsTemplates = Package['useraccounts:core'].AccountsTemplates;
Accounts = Package['accounts-base'].Accounts;
AccountsServer = Package['accounts-base'].AccountsServer;
Meteor = Package.meteor.Meteor;
WebApp = Package.webapp.WebApp;
main = Package.webapp.main;
WebAppInternals = Package.webapp.WebAppInternals;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
LaunchScreen = Package['launch-screen'].LaunchScreen;
Blaze = Package.ui.Blaze;
UI = Package.ui.UI;
Handlebars = Package.ui.Handlebars;
T9n = Package['softwarerero:accounts-t9n'].T9n;
Autoupdate = Package.autoupdate.Autoupdate;
HTML = Package.htmljs.HTML;


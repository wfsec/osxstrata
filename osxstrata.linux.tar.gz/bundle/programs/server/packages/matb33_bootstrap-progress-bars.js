(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['matb33:bootstrap-progress-bars'] = {};

})();

//# sourceMappingURL=matb33_bootstrap-progress-bars.js.map
